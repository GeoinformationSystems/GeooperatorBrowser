/*==================================================
 *  Exhibit.TileView German localization
 *==================================================
 */

if (!("l10n" in Exhibit.TileView)) {
    Exhibit.TileView.l10n = {};
}

Exhibit.TileView.l10n.viewLabel = "Kachelansicht";
Exhibit.TileView.l10n.viewTooltip = "Zeige Elemente in einer Kachelansicht (als Liste)";
