/*==================================================
 *  Exhibit.ThumbnailView Chinese localization
 *==================================================
 */

if (!("l10n" in Exhibit.ThumbnailView)) {
    Exhibit.ThumbnailView.l10n = {};
}

Exhibit.ThumbnailView.l10n.viewLabel = "Thumbnails";
Exhibit.ThumbnailView.l10n.viewTooltip = "View items as thumbnails";
