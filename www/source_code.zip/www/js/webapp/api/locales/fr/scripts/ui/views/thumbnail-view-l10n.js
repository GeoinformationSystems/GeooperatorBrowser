﻿/*==================================================
 *  Exhibit.ThumbnailView French localization
 *==================================================
 */

if (!("l10n" in Exhibit.ThumbnailView)) {
    Exhibit.ThumbnailView.l10n = {};
}

Exhibit.ThumbnailView.l10n.viewLabel = "Vignettes";
Exhibit.ThumbnailView.l10n.viewTooltip = "Voir les items commes des vignettes";
