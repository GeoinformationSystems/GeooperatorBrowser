﻿/*==================================================
 *  Exhibit.TileView French localization
 *==================================================
 */

if (!("l10n" in Exhibit.TileView)) {
    Exhibit.TileView.l10n = {};
}

Exhibit.TileView.l10n.viewLabel = "Blocs";
Exhibit.TileView.l10n.viewTooltip = "Voir les items sous forme de blocs dans une liste"
